<?php

class Counter_model extends CI_Model
{
	function insert_counter($data){

		if($data['id'] == null){
			$query = $this->db->insert('counter',$data);

			if($query){
				return TRUE;
			}
			else{
				return FALSE;
			}
		}
		else{
			$this->db->where('id', $data['id']);
			$query = $this->db->update('counter', $data);
			if($query){
				return TRUE;
			}
			else{
				return FALSE;
			}
		}

		

	}


	function show_counter(){

		$query = $this->db->get('counter');
		$res = $query->result_array();
	 	return $res;

	}
}

?>