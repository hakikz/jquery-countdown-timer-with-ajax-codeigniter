<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index(){

		$this->load->model('counter_model');
		$data['results'] = $this->counter_model->show_counter();
		$this->load->view('master/header', $data);
		$this->load->view('index', $data);
		$this->load->view('master/footer');
	}

	public function settings(){

		$this->load->model('counter_model');
		$data['results'] = $this->counter_model->show_counter();
		$this->load->view('master/header', $data);

		$this->load->view('settings', $data);
		$this->load->view('master/footer');
	}

	public function counter_submit(){

		$this->form_validation->set_rules('set_title', 'set_title', 'required');
		$this->form_validation->set_rules('counterdate', 'counterdate', 'required');
		$this->form_validation->set_rules('font-size', 'font-size', 'required');
		$this->form_validation->set_rules('counter-color', 'counter-color', 'required');
		$this->form_validation->set_rules('label-color', 'label-color', 'required');


		if ($this->form_validation->run() == FALSE){

			$this->session->set_flashdata('error', 'Set Title, Date, Font Size, Counter Color and Label Color');

        	redirect('Welcome/settings');
                
        }
        else{

        	$config['upload_path']          = './image/';
            $config['allowed_types']        = 'gif|jpg|png';
            // $config['max_size']             = 100;
            // $config['max_width']            = 1024;
            // $config['max_height']           = 768;

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('bg-img')){

        		$image_path = $this->upload->data();
        		$image = "image/".$image_path[file_name];
            	$data = array(
					'title' => $this->input->post('set_title'),
					'date' => date('Y-m-d',strtotime($this->input->post('counterdate'))),
					'font_size' => $this->input->post('font-size'),
					'bg_color' => '',
					'counter_color' => $this->input->post('counter-color'),
					'label_color' => $this->input->post('label-color'),
					'id' => $this->input->post('id'),
					'bg_image' => $image
				);

				$this->load->model('counter_model');
				$res = $this->counter_model->insert_counter($data);

				if($res == TRUE){
					$this->session->set_flashdata('success', 'Successfully Changed');
					redirect("Welcome");
				}
				else{
					$this->session->set_flashdata('error', 'Something went wrong');
					redirect("Welcome/settings");
				}
	            

            }
            else{

            	$this->load->model('counter_model');
				$data = $this->counter_model->show_counter();

				foreach ($data as $counter) {

					$url = $counter['bg_image'];
				}

				// $unset = base_url().$url;
				if($url != '')
				{
					unlink(FCPATH . $url);
				}
				
				
            	
            	$data = array(
					'title' => $this->input->post('set_title'),
					'date' => date('Y-m-d',strtotime($this->input->post('counterdate'))),
					'font_size' => $this->input->post('font-size'),
					'bg_color' => $this->input->post('bg-color'),
					'counter_color' => $this->input->post('counter-color'),
					'label_color' => $this->input->post('label-color'),
					'id' => $this->input->post('id'),
					'bg_image' => ''
				);

				$this->load->model('counter_model');
				$res = $this->counter_model->insert_counter($data);

				if($res == TRUE){
					$this->session->set_flashdata('success', 'Successfully Changed');
					redirect("Welcome");
				}
				else{
					$this->session->set_flashdata('error', 'Something went wrong');
					redirect("Welcome/settings");
				}
            }
			
        }



	}
}
