<?php
foreach ($results as $settings_counter) {
    $font_size = $settings_counter['font_size'];
    $bg_color = $settings_counter['bg_color'];
    $counter_color = $settings_counter['counter_color'];
    $label_color = $settings_counter['label_color'];
    $title = $settings_counter['title'];
    $id = $settings_counter['id'];
    $date = $settings_counter['date'];
  }
?>
<div class="container">
  <div class="row top-space">
    <?php if($this->session->flashdata('error')){ ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $this->session->flashdata('error'); ?>.
        </div>
    <?php } ?>
    <div class="col-md-5 simple-border">
      <div class="starter-left">
        <form class="counter_form" name="counter_form" method="post" action="<?= site_url('Welcome/counter_submit') ?>" enctype="multipart/form-data">
          <div class="row differ">
            <div class="col-md-12">
              <div class="form-group">
                <label>Set Title</label><br/>
                <small>(The Title of Counter)</small>
                <input type="text" name="set_title" class="form-control" id="set_title" value="<?= $title; ?>">
              </div>
            </div>
          </div>
          <div class="row non-differ">
            <div class="col-md-6">
              <div class="form-group">
                <label>Set Date</label><br>
                <small>(The Counter Date)</small><br>
                <input type='text' name="counterdate" class="form-control" id='counterdate' value="<?= date("m/d/Y", strtotime($date)); ?>"/>
              </div>
            </div>

            <div class="col-md-6">
              <div class="form-group">
                <label>Font Size</label><br/>
                <small>(The Counter Font Size in Pixel Unit)</small>
                <input type="text" name="font-size" class="form-control" id="set_font_size" value="<?= $font_size; ?>">
              </div>
            </div>

          </div>
          
          <div class="row differ">
            <div class="col-md-6">
              <div class="form-group">
                <label>Counter Background Color</label><br>
                <small>(The Counter Background Color)</small><br>
                <input type="text" name="bg-color" class="form-control" id="bg-color" value="<?= $bg_color; ?>">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label>Counter Background Image</label><br>
                <small>(The Counter Background Image)</small>
                <input type="file" name="bg-img" id="bg-img">
              </div>
            </div>
          </div>

          <div class="row non-differ">
            <div class="col-md-6">
              <div class="form-group">
                <label>Counter Color</label><br/>
                <small>(The Counter Color)</small><br>
                <input type="text" name="counter-color" class="form-control" id="counter-color" value="<?= $counter_color; ?>">
              </div>
            </div>

            <div class="col-md-6">

              <div class="form-group">
                <label>Label Color</label><br>
                <small>(The Counter Label Color)</small><br>
                <input type="text" name="label-color" class="form-control" id="label-color" value="<?= $label_color; ?>">
              </div>
            </div>
          </div>

          <div class="form-group">
            <?php if($id != null){ ?>
              <input type="hidden" name="id" value="<?= $id; ?>">
            <?php }else{ ?>
              <input type="hidden" name="id" value="">
            <?php } ?>
            <input type="submit" name="submit" class="btn btn-success btn-lg" value="Save">
          </div>
        </form>
      </div>

    </div>
    <div class="col-md-7">
      <div class="counter_full">
        <div class="starter-middle">
          <h1 id="title"><?= $title; ?></h1>
          <!-- <p class="lead">Use this document as a way to quickly start any new project.<br> All you get is this text and a mostly barebones HTML document.</p> -->
          <div class="panel panel-default" data-toggle="tooltip" data-placement="top" title="Beautifull, insn't it?">
            <div class="panel-body">
              <div class="lead" id="clock"></div>
            </div>
          </div>


          <div class="btn-group" data-toggle="buttons">
            <label class="btn btn-default" id="btn-pause">
              <input type="radio" name="options" id="option2" autocomplete="off">
              <i class="glyphicon glyphicon-pause"></i>
              Pause
            </label>

            <label class="btn btn-default active" id="btn-resume">
              <input type="radio" name="options" id="option2" autocomplete="off" checked>
              <i class="glyphicon glyphicon-play"></i>
              Resume
            </label>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
  // Turn on Bootstrap
  $('[data-toggle="tooltip"]').tooltip();

  // 15 days from now!
  function setDayForTimer() {
    return new Date(new Date('<?= date("m/d/Y", strtotime($date)); ?>').valueOf() + (1 - 1) * 24 * 60 * 60 * 1000);
  }

  var $clock = $('#clock');

  $clock.countdown(setDayForTimer(), function(event) {
    $(this).html(event.strftime('%D days %H:%M:%S'));
  });

  $('#btn-pause').click(function() {
    $clock.countdown('pause');
  });

  $('#btn-resume').click(function() {
    $clock.countdown('resume');
  });


  // Color Picker


  $(function () {
      $('#bg-color').colorpicker();
      $('#counter-color').colorpicker();
      $('#label-color').colorpicker();
  });


  // DateTime Picker
  $(function () {
      $(function () {
          $('#counterdate').datepicker({
            dateFormat: "mm/dd/yy",
            showOtherMonths: true,
            selectOtherMonths: true,
            autoclose: true,
            changeMonth: true,
            changeYear: true,
            orientation: "bottom"
        });
      });
  });


  //On Change Function for Settings

  $(document).ready(function(){

    

    $("#set_title").change(function(){
        var set_title = $('#set_title').val();
        $('#title').html(set_title);
    });

    $("#set_font_size").change(function(){
        var set_font_size = $('#set_font_size').val();
        var text_input = $('#title, #clock');
        var font_size = set_font_size+'px';
        text_input.css("font-size", font_size);
    });

    $("#counterdate").change(function(){
        var counterdate = $('#counterdate').val();
        function setDayForTimer() {
          return new Date(new Date(counterdate).valueOf() + (1 - 1) * 24 * 60 * 60 * 1000);
        }
        var $clock = $('#clock');

        $clock.countdown(setDayForTimer(), function(event) {
          $(this).html(event.strftime('%D days %H:%M:%S'));
        });

        $('#btn-pause').click(function() {
          $clock.countdown('pause');
        });

        $('#btn-resume').click(function() {
          $clock.countdown('resume');
        });
    });

    $("#bg-color").change(function(){
        $("#bg-img").val('');
        var bg_color = $('#bg-color').val();
        var text_input = $('.counter_full');
        text_input.css("background", bg_color);
        // alert(bg_color);

    });

    $("#counter-color").change(function(){
        var counter_color = $('#counter-color').val();
        var text_input = $('#clock');
        text_input.css("color", counter_color);
        // alert(bg_color);
    });

    $("#label-color").change(function(){
        var label_color = $('#label-color').val();
        var text_input = $('#title');
        text_input.css("color", label_color);
        // alert(bg_color);
    });

    $("#bg-img").change(function(){

        $("#bg-color").val('');
        var file = this.files[0];
        
        var reader = new FileReader();
        reader.onloadend = function () {
           $('.counter_full').css('background-image', 'url("' + reader.result + '")');
           $('.counter_full').css('width', 'auto');
           $('.counter_full').css('height', 'auto');
        }
        if (file) {
            reader.readAsDataURL(file);

        } else {

        }
    });

    $("#counter_form").submit(function(e){
      e.preventDefault();
    });


  }); 

</script>