<?php
foreach ($results as $header_counter) {
    $font_size = $header_counter['font_size'];
    $bg_color = $header_counter['bg_color'];
    $counter_color = $header_counter['counter_color'];
    $label_color = $header_counter['label_color'];
    $id = $header_counter['id'];
    $bg_img = $header_counter['bg_image'];
  }
?>
<!DOCTYPE html>
<html>
<head>
  <title>jQuery Ajax with CodeIgniter</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width">
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
  <script src="http://cdn.rawgit.com/hilios/jQuery.countdown/2.2.0/dist/jquery.countdown.min.js"></script>
  <link rel="stylesheet" type="text/css" href="http://netdna.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">

  <!-- Custom CSS -->
  <link rel="stylesheet" type="text/css" href="<?= base_url('asset/style.css') ?>">

  <!-- /End Custom CSS -->

  <!-- Color Picker -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-colorpicker/2.5.1/js/bootstrap-colorpicker.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-colorpicker/2.5.1/css/bootstrap-colorpicker.css" />
  <!-- /End Color Picker -->

  <!-- DateTime Picker -->
  <!-- <script src="http://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment-with-locales.js"></script> -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.1/css/bootstrap-datepicker.min.css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.7.1/js/bootstrap-datepicker.min.js"></script>
  <!-- /End DateTime Picker -->

  <style type="text/css">
    <?php if($font_size != ''){
    ?>
      #title, #clock{
        font-size: <?= $font_size; ?>px;
      }
    <?php
    }
    ?>

    <?php if($bg_color != ''){
    ?>
      .counter_full{
        background-color: <?= $bg_color; ?>;
        height: 650px;
        margin-top: 20px
        margin-bottom: 20px;
        width: auto;
        display: block;
      }
    <?php
    }elseif($bg_img != ''){
    ?>
      .counter_full{
        background-image: url("<?= base_url($bg_img); ?>");
        width: auto;
        height: 650px;
      }

    <?php } ?>

    <?php if($counter_color != ''){
    ?>
      #clock{
        color: <?= $counter_color; ?>;
      }
    <?php
    }
    ?>
    <?php if($label_color != ''){
    ?>
      #title{
        color: <?= $label_color; ?>;
      }
    <?php
    }
    ?>

  </style>
</head>
<body>
<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="<?= site_url('welcome/index') ?>">jQuery, Ajax with CodeIgniter</a>
    </div>
    <div id="navbar" class="collapse navbar-collapse">
      <ul class="nav navbar-nav">
        <li <?php if($this->uri->segment(2)=="index"){echo 'class="active"';}?>><a href="<?= site_url('welcome/index') ?>">Home</a></li>
        <li <?php if($this->uri->segment(2)=="settings"){echo 'class="active"';}?>><a href="<?= site_url('welcome/settings') ?>">Settings</a></li>
      </ul>
    </div>
  </div>
</nav>

