<footer class="footer">
    <!-- For copyright -->
    <div class="col-md-12">
      &copy; Allrights Reserved by Hakik Zaman
    </div>
    <!-- / End copyrigh -->
      
</footer>

<script type="text/javascript">
    $(document).ready(function() {

        // To vanish the information above 

        setTimeout(function() {
          $(".alert-dismissable").fadeOut().empty();
        }, 5000);
    });
</script>
</body>
</html>
