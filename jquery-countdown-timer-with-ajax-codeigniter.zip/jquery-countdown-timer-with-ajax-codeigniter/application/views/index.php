<?php 
  foreach ($results as $counter) {
    $title = $counter['title'];
    $date = $counter['date'];
  } 
?>

  <div class="counter_full">
    <div class="starter-template">
      <?php if($this->session->flashdata('success')){ ?>
          <div class="alert alert-success alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <?php echo $this->session->flashdata('success'); ?>.
          </div>
      <?php } ?>
      <h1 id="title"><?= $title; ?></h1><br>
      <!-- <p class="lead">Use this document as a way to quickly start any new project.<br> All you get is this text and a mostly barebones HTML document.</p> -->
      <div class="panel panel-default" data-toggle="tooltip" data-placement="top" title="Beautifull, insn't it?">
        <div class="panel-body">
          <div class="lead" id="clock"></div>
        </div>
      </div>


      <div class="btn-group" data-toggle="buttons">
        <label class="btn btn-default" id="btn-pause">
          <input type="radio" name="options" id="option2" autocomplete="off">
          <i class="glyphicon glyphicon-pause"></i>
          Pause
        </label>

        <label class="btn btn-default active" id="btn-resume">
          <input type="radio" name="options" id="option2" autocomplete="off" checked>
          <i class="glyphicon glyphicon-play"></i>
          Resume
        </label>
      </div>
    </div>
  </div>

<script type="text/javascript">
  // Turn on Bootstrap
  $('[data-toggle="tooltip"]').tooltip();

  // 15 days from now!
  function setDayForTimer() {
    return new Date(new Date('<?= date("m/d/Y", strtotime($date)); ?>').valueOf() + (1 - 1) * 24 * 60 * 60 * 1000);
  }

  var $clock = $('#clock');

  $clock.countdown(setDayForTimer(), function(event) {
    $(this).html(event.strftime('%D days %H:%M:%S'));
  });

  $('#btn-pause').click(function() {
    $clock.countdown('pause');
  });

  $('#btn-resume').click(function() {
    $clock.countdown('resume');
  });

</script>
